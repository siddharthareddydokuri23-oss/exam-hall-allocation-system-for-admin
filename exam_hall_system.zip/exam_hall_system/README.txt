SETUP
1. Install XAMPP/WAMP (Apache + PHP 8+ + MySQL).
2. Copy this folder to htdocs/exam_hall_system.
3. Import schema.sql in phpMyAdmin (or: mysql -u root < schema.sql).
4. Edit db.php if your MySQL user/password differ.
5. Open http://localhost/exam_hall_system/

WORKFLOW: add Halls -> add Students -> Allocate -> view/print seating -> students use "Find My Seat".
