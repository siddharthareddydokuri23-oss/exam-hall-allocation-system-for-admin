<?php include 'header.php';
$examId = (int)($_GET['exam_id'] ?? 0);
$exam = $pdo->prepare("SELECT * FROM exams WHERE id=?"); $exam->execute([$examId]); $exam = $exam->fetch();
if (!$exam) { echo '<p class="msg error">Exam not found.</p>'; include 'footer.php'; exit; }

$used = $pdo->prepare("SELECT h.*, COUNT(a.id) used FROM halls h JOIN allocations a ON a.hall_id=h.id
                       WHERE a.exam_id=? GROUP BY h.id ORDER BY h.name");
$used->execute([$examId]); $halls = $used->fetchAll();
?>
<h1><?= e($exam['name']) ?></h1>
<p><?= e($exam['exam_date']) ?> &middot; <?= e($exam['session']) ?>
   <button class="no-print" onclick="window.print()">Print</button></p>

<?php foreach ($halls as $h):
  $q = $pdo->prepare("SELECT a.seat_no, s.roll_no, s.name, s.department FROM allocations a
                      JOIN students s ON s.id=a.student_id WHERE a.exam_id=? AND a.hall_id=?");
  $q->execute([$examId, $h['id']]);
  $seats = [];
  foreach ($q as $r) $seats[$r['seat_no']] = $r;
?>
<section class="hall">
  <h2>Hall <?= e($h['name']) ?> <small>(<?= $h['used'] ?> / <?= $h['rows_count'] * $h['cols_count'] ?> seats)</small></h2>
  <div class="grid" style="grid-template-columns: repeat(<?= $h['cols_count'] ?>, minmax(90px, 1fr));">
    <?php for ($i = 1; $i <= $h['rows_count'] * $h['cols_count']; $i++): $s = $seats[$i] ?? null; ?>
      <div class="seat <?= $s ? '' : 'empty' ?>">
        <span class="no"><?= $i ?></span>
        <?php if ($s): ?><strong><?= e($s['roll_no']) ?></strong><em><?= e($s['department']) ?></em><?php endif; ?>
      </div>
    <?php endfor; ?>
  </div>
</section>
<?php endforeach; ?>
<?php include 'footer.php'; ?>
