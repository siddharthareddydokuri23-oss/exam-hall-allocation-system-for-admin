<?php include 'header.php';
$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['delete'])) {
        $pdo->prepare("DELETE FROM halls WHERE id=?")->execute([(int)$_POST['delete']]);
        $msg = 'Hall deleted.';
    } else {
        $name = trim($_POST['name']); $r = (int)$_POST['rows']; $c = (int)$_POST['cols'];
        if ($name === '' || $r < 1 || $c < 1) { $msg = 'Enter a valid name, rows and columns.'; }
        else {
            try {
                $pdo->prepare("INSERT INTO halls (name, rows_count, cols_count) VALUES (?,?,?)")->execute([$name, $r, $c]);
                $msg = 'Hall added.';
            } catch (PDOException $ex) { $msg = 'Hall name already exists.'; }
        }
    }
}
$halls = $pdo->query("SELECT * FROM halls ORDER BY name")->fetchAll();
?>
<h1>Exam Halls</h1>
<?php if ($msg): ?><p class="msg"><?= e($msg) ?></p><?php endif; ?>
<form method="post" class="inline">
  <input name="name" placeholder="Hall name (e.g. A-101)" required>
  <input type="number" name="rows" min="1" placeholder="Rows" required>
  <input type="number" name="cols" min="1" placeholder="Columns" required>
  <button>Add hall</button>
</form>
<table>
  <tr><th>Hall</th><th>Rows</th><th>Columns</th><th>Capacity</th><th></th></tr>
  <?php foreach ($halls as $h): ?>
  <tr>
    <td><?= e($h['name']) ?></td><td><?= $h['rows_count'] ?></td><td><?= $h['cols_count'] ?></td>
    <td><?= $h['rows_count'] * $h['cols_count'] ?></td>
    <td><form method="post" onsubmit="return confirm('Delete this hall and its allocations?')">
      <button class="danger" name="delete" value="<?= $h['id'] ?>">Delete</button></form></td>
  </tr>
  <?php endforeach; ?>
</table>
<?php include 'footer.php'; ?>
