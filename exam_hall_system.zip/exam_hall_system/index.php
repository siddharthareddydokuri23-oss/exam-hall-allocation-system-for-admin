<?php include 'header.php';
$halls = $pdo->query("SELECT COUNT(*) c, COALESCE(SUM(rows_count*cols_count),0) cap FROM halls")->fetch();
$students = $pdo->query("SELECT COUNT(*) c FROM students")->fetch()['c'];
$exams = $pdo->query("SELECT * FROM exams ORDER BY exam_date DESC, id DESC")->fetchAll();
?>
<h1>Dashboard</h1>
<div class="cards">
  <div class="card"><h2><?= $halls['c'] ?></h2><p>Halls</p></div>
  <div class="card"><h2><?= $halls['cap'] ?></h2><p>Total seats</p></div>
  <div class="card"><h2><?= $students ?></h2><p>Students</p></div>
  <div class="card"><h2><?= count($exams) ?></h2><p>Exams scheduled</p></div>
</div>
<h2>Exams</h2>
<table>
  <tr><th>Name</th><th>Date</th><th>Session</th><th></th></tr>
  <?php foreach ($exams as $x): ?>
  <tr>
    <td><?= e($x['name']) ?></td><td><?= e($x['exam_date']) ?></td><td><?= e($x['session']) ?></td>
    <td><a class="btn" href="view.php?exam_id=<?= $x['id'] ?>">View seating</a></td>
  </tr>
  <?php endforeach; if (!$exams): ?><tr><td colspan="4">No exams yet. Go to Allocate.</td></tr><?php endif; ?>
</table>
<?php include 'footer.php'; ?>
