<?php include 'header.php';
$result = null; $searched = false;
if (isset($_GET['roll_no'])) {
    $searched = true;
    $q = $pdo->prepare("SELECT s.name, s.roll_no, e.name exam, e.exam_date, e.session, h.name hall, a.seat_no
        FROM allocations a JOIN students s ON s.id=a.student_id JOIN exams e ON e.id=a.exam_id
        JOIN halls h ON h.id=a.hall_id WHERE s.roll_no=? ORDER BY e.exam_date DESC");
    $q->execute([trim($_GET['roll_no'])]);
    $result = $q->fetchAll();
}
?>
<h1>Find My Seat</h1>
<form method="get" class="inline">
  <input name="roll_no" placeholder="Enter roll number" value="<?= e($_GET['roll_no'] ?? '') ?>" required>
  <button>Search</button>
</form>
<?php if ($searched && !$result): ?><p class="msg error">No allocation found for that roll number.</p><?php endif; ?>
<?php if ($result): ?>
<table>
  <tr><th>Exam</th><th>Date</th><th>Session</th><th>Hall</th><th>Seat</th></tr>
  <?php foreach ($result as $r): ?>
  <tr><td><?= e($r['exam']) ?></td><td><?= e($r['exam_date']) ?></td><td><?= e($r['session']) ?></td>
      <td><?= e($r['hall']) ?></td><td><?= $r['seat_no'] ?></td></tr>
  <?php endforeach; ?>
</table>
<?php endif; ?>
<?php include 'footer.php'; ?>
