<?php include 'header.php';
$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['delete'])) {
        $pdo->prepare("DELETE FROM students WHERE id=?")->execute([(int)$_POST['delete']]);
        $msg = 'Student deleted.';
    } elseif (isset($_POST['bulk'])) {
        // Format per line: roll_no, name, department, year
        $ins = $pdo->prepare("INSERT IGNORE INTO students (roll_no,name,department,year) VALUES (?,?,?,?)");
        $added = 0;
        foreach (preg_split('/\r?\n/', trim($_POST['bulk'])) as $line) {
            $p = array_map('trim', explode(',', $line));
            if (count($p) === 4 && $p[0] !== '') { $ins->execute($p); $added += $ins->rowCount(); }
        }
        $msg = "$added student(s) imported.";
    } else {
        try {
            $pdo->prepare("INSERT INTO students (roll_no,name,department,year) VALUES (?,?,?,?)")
                ->execute([trim($_POST['roll_no']), trim($_POST['name']), strtoupper(trim($_POST['department'])), (int)$_POST['year']]);
            $msg = 'Student added.';
        } catch (PDOException $ex) { $msg = 'Roll number already exists.'; }
    }
}
$students = $pdo->query("SELECT * FROM students ORDER BY roll_no")->fetchAll();
?>
<h1>Students</h1>
<?php if ($msg): ?><p class="msg"><?= e($msg) ?></p><?php endif; ?>
<form method="post" class="inline">
  <input name="roll_no" placeholder="Roll no" required>
  <input name="name" placeholder="Name" required>
  <input name="department" placeholder="Dept (CSE, ECE...)" required>
  <input type="number" name="year" min="1" max="4" placeholder="Year" required>
  <button>Add student</button>
</form>
<details>
  <summary>Bulk import</summary>
  <form method="post">
    <textarea name="bulk" rows="5" placeholder="roll_no, name, department, year&#10;23A81A0501, Ravi Kumar, CSE, 3"></textarea>
    <button>Import</button>
  </form>
</details>
<table>
  <tr><th>Roll no</th><th>Name</th><th>Dept</th><th>Year</th><th></th></tr>
  <?php foreach ($students as $s): ?>
  <tr>
    <td><?= e($s['roll_no']) ?></td><td><?= e($s['name']) ?></td><td><?= e($s['department']) ?></td><td><?= $s['year'] ?></td>
    <td><form method="post"><button class="danger" name="delete" value="<?= $s['id'] ?>">Delete</button></form></td>
  </tr>
  <?php endforeach; ?>
</table>
<?php include 'footer.php'; ?>
