CREATE DATABASE IF NOT EXISTS exam_hall CHARACTER SET utf8mb4;
USE exam_hall;

CREATE TABLE halls (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(50) NOT NULL UNIQUE,
  rows_count INT NOT NULL,
  cols_count INT NOT NULL
);

CREATE TABLE students (
  id INT AUTO_INCREMENT PRIMARY KEY,
  roll_no VARCHAR(30) NOT NULL UNIQUE,
  name VARCHAR(100) NOT NULL,
  department VARCHAR(50) NOT NULL,
  year TINYINT NOT NULL
);

CREATE TABLE exams (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  exam_date DATE NOT NULL,
  session VARCHAR(20) NOT NULL
);

CREATE TABLE allocations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  exam_id INT NOT NULL,
  student_id INT NOT NULL,
  hall_id INT NOT NULL,
  seat_no INT NOT NULL,
  UNIQUE (exam_id, student_id),
  UNIQUE (exam_id, hall_id, seat_no),
  FOREIGN KEY (exam_id) REFERENCES exams(id) ON DELETE CASCADE,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  FOREIGN KEY (hall_id) REFERENCES halls(id) ON DELETE CASCADE
);
