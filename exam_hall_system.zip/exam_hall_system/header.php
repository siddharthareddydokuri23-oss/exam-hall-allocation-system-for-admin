<?php require_once 'db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Exam Hall Allocation System</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<nav>
  <span class="brand">Exam Hall Allocation</span>
  <a href="index.php">Dashboard</a>
  <a href="halls.php">Halls</a>
  <a href="students.php">Students</a>
  <a href="allocate.php">Allocate</a>
  <a href="search.php">Find My Seat</a>
</nav>
<main>
