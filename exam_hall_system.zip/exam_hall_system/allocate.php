<?php include 'header.php';
$msg = ''; $err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']); $date = $_POST['exam_date']; $session = $_POST['session']; $year = (int)$_POST['year'];

    // 1. Students (optionally filtered by year)
    if ($year > 0) { $st = $pdo->prepare("SELECT * FROM students WHERE year=? ORDER BY roll_no"); $st->execute([$year]); }
    else { $st = $pdo->query("SELECT * FROM students ORDER BY roll_no"); }
    $students = $st->fetchAll();

    // 2. Halls and capacity
    $halls = $pdo->query("SELECT * FROM halls ORDER BY name")->fetchAll();
    $capacity = array_sum(array_map(fn($h) => $h['rows_count'] * $h['cols_count'], $halls));

    if ($name === '' || !$date) { $err = 'Exam name and date are required.'; }
    elseif (!$students) { $err = 'No students found for this selection.'; }
    elseif ($capacity < count($students)) { $err = "Not enough seats: " . count($students) . " students, $capacity seats."; }
    else {
        // 3. Interleave departments so classmates are not seated side by side
        $groups = [];
        foreach ($students as $s) $groups[$s['department']][] = $s;
        uasort($groups, fn($a, $b) => count($b) <=> count($a));
        $groups = array_values($groups);
        $queue = [];
        while ($groups) {
            foreach ($groups as $i => &$g) {
                $queue[] = array_shift($g);
                if (!$g) unset($groups[$i]);
            }
            unset($g);
            $groups = array_values($groups);
        }

        // 4. Fill halls sequentially, seat by seat
        $pdo->beginTransaction();
        $pdo->prepare("INSERT INTO exams (name, exam_date, session) VALUES (?,?,?)")->execute([$name, $date, $session]);
        $examId = $pdo->lastInsertId();
        $ins = $pdo->prepare("INSERT INTO allocations (exam_id, student_id, hall_id, seat_no) VALUES (?,?,?,?)");
        $k = 0;
        foreach ($halls as $h) {
            $cap = $h['rows_count'] * $h['cols_count'];
            for ($seat = 1; $seat <= $cap && $k < count($queue); $seat++, $k++) {
                $ins->execute([$examId, $queue[$k]['id'], $h['id'], $seat]);
            }
            if ($k >= count($queue)) break;
        }
        $pdo->commit();
        header("Location: view.php?exam_id=$examId"); exit;
    }
}
?>
<h1>Allocate Exam Halls</h1>
<?php if ($err): ?><p class="msg error"><?= e($err) ?></p><?php endif; ?>
<form method="post" class="stack">
  <label>Exam name <input name="name" placeholder="Mid-1 Examination" required></label>
  <label>Date <input type="date" name="exam_date" required></label>
  <label>Session
    <select name="session"><option>Forenoon</option><option>Afternoon</option></select>
  </label>
  <label>Year
    <select name="year"><option value="0">All years</option>
      <?php for ($y = 1; $y <= 4; $y++): ?><option value="<?= $y ?>">Year <?= $y ?></option><?php endfor; ?>
    </select>
  </label>
  <button>Generate allocation</button>
</form>
<p class="hint">Students from different departments are alternated, then halls are filled in name order.</p>
<?php include 'footer.php'; ?>
